(() => {
// ===== utils =====
function nowISO(){ return new Date().toISOString(); }
function cssPath(el){
  if (!el || el.nodeType !== 1) return "";
  const path = [];
  while (el && el.nodeType === 1 && el !== document.documentElement) {
    let selector = el.nodeName.toLowerCase();
    if (el.id) { selector += "#" + CSS.escape(el.id); path.unshift(selector); break; }
    const cls = Array.from(el.classList).filter(c => c.length <= 32).slice(0, 3);
    if (cls.length) selector += "." + cls.map(c => CSS.escape(c)).join(".");
    const parent = el.parentNode;
    if (parent) {
      const tag = el.tagName;
      const siblings = Array.from(parent.children).filter(n => n.tagName === tag);
      if (siblings.length > 1) { const idx = siblings.indexOf(el) + 1; selector += ":nth-of-type(" + idx + ")"; }
    }
    path.unshift(selector); el = el.parentElement;
  }
  return path.join(" > ");
}
function sanitizeText(t){ return (t||"").replace(/\s+/g," ").trim(); }
function toAbsoluteUrl(u){ try { return new URL(u, location.href).href; } catch { return u; } }
function originKey(){ try{ return new URL(location.href).origin; }catch{ return "*"; } }

// ---- title helpers ----
function sanitizeTitleForFolder(t){
  if (!t) return "chat";
  t = t.replace(/[\u0000-\u001f\u007f-\u009f]/g, "").replace(/[\u{1F300}-\u{1FAFF}\u{1F600}-\u{1F64F}]/ug, "");
  t = t.replace(/\s+/g, " ").trim();
  t = t.replace(/[:*?"<>|\\\/]/g, "-");
  if (t.length > 80) t = t.slice(0, 80).trim();
  return t || "chat";
}
function getLinkedInChatTitle(){
  try {
    const selCandidates = [
      "h2.msg-entity-lockup__entity-title.truncate.pr2.hoverable-link-text",
      "h2.msg-entity-lockup__entity-title",
      ".msg-entity-lockup__entity-title",
      "main[role='main'] h2.msg-entity-lockup__entity-title",
      "h2.msg-thread__participants",
      ".msg-thread__participants",
      ".msg-conversation-head__title h2",
      ".msg-conversation-head__title",
      ".msg-conversation__participant-names",
      ".msg-s-message-list__participants",
      "header.msg-conversation-head h2",
      "header.msg-conversation-head [data-control-name='conversation_header']"
    ];
    for (const s of selCandidates) {
      const el = document.querySelector(s);
      if (el && el.textContent && el.textContent.trim().length>0) return el.textContent.trim();
    }
    const aria = document.querySelector("main[role='main'] [aria-label*='会话'], main[role='main'] [aria-label*='Conversation']");
    if (aria && aria.getAttribute("aria-label")) return aria.getAttribute("aria-label");
    return document.title;
  } catch(e){ return document.title; }
}
function getGenericChatTitle(){
  const selCandidates = ["h1", "h2", ".chat-title", ".conversation-title", "[role='heading']", "header h1", "header h2", ".thread-title", ".room-title"];
  for (const s of selCandidates) {
    const el = document.querySelector(s);
    if (el && el.textContent && el.textContent.trim().length>0) return el.textContent.trim();
  }
  return document.title;
}
function getChatTitle(){
  const isLI = /(^|\.)linkedin\.com$/.test(location.hostname);
  const raw = isLI ? getLinkedInChatTitle() : getGenericChatTitle();
  return sanitizeTitleForFolder(raw);
}
function topSendersFromMessages(msgs){
  const freq = new Map();
  for (const m of (msgs || [])) {
    const s = (m && m.sender && String(m.sender).trim()) || "";
    if (!s) continue;
    const key = s.slice(0, 128);
    freq.set(key, (freq.get(key) || 0) + 1);
  }
  return Array.from(freq.entries()).sort((a,b)=>b[1]-a[1]).map(x=>x[0]).slice(0,3);
}
function looksGenericTitle(t){
  if (!t) return true;
  const tt = t.toLowerCase();
  return tt === 'chat' || tt === 'conversation' || tt === 'messaging | linkedin' || /^linkedin/i.test(tt) || /^messages?$/.test(tt) || tt.length < 2;
}
function refineChatTitleWithMessages(baseTitle, messages){
  let title = baseTitle;
  if (looksGenericTitle(title)) {
    const tops = topSendersFromMessages(messages);
    if (tops.length) title = tops.join('、');
  }
  return sanitizeTitleForFolder(title);
}

// ---- nearest helpers for sender/timestamp ----
function nearestTextBySelectors(el, selectors, maxDepth){
  maxDepth = maxDepth || 4;
  try {
    for (let i=0;i<selectors.length;i++){
      const sel = selectors[i];
      try {
        if (el.matches && el.matches(sel)) {
          const t0 = (el.textContent||'').trim();
          if (t0) return t0;
        }
      } catch(e){}
      const found = el.querySelector ? el.querySelector(sel) : null;
      if (found && found.textContent && found.textContent.trim()) return found.textContent.trim();
    }
    let cur = el.parentElement; let depth = 0;
    while (cur && depth < maxDepth) {
      for (let j=0;j<selectors.length;j++){
        const sel2 = selectors[j];
        const n = cur.querySelector(sel2);
        if (n && n.textContent && n.textContent.trim()) return n.textContent.trim();
      }
      cur = cur.parentElement; depth++;
    }
    cur = el.previousElementSibling; depth = 0;
    while (cur && depth < maxDepth) {
      for (let k=0;k<selectors.length;k++){
        const sel3 = selectors[k];
        let n2 = null;
        try { n2 = (cur.matches && cur.matches(sel3)) ? cur : (cur.querySelector && cur.querySelector(sel3)); } catch(e){}
        if (n2 && n2.textContent && n2.textContent.trim()) return n2.textContent.trim();
      }
      cur = cur.previousElementSibling; depth++;
    }
  } catch(e){}
  return null;
}
function nearestAttrBySelectors(el, attrSelectors, maxDepth){
  maxDepth = maxDepth || 4;
  try {
    for (let i=0;i<attrSelectors.length;i++){
      const [sel, attrs] = attrSelectors[i];
      const n = el.querySelector ? el.querySelector(sel) : null;
      if (n) for (let a=0;a<attrs.length;a++){ const v = n.getAttribute ? n.getAttribute(attrs[a]) : null; if (v) return v; }
    }
    let cur = el.parentElement; let depth = 0;
    while (cur && depth < maxDepth) {
      for (let j=0;j<attrSelectors.length;j++){
        const [sel2, attrs2] = attrSelectors[j];
        const n2 = cur.querySelector(sel2);
        if (n2) for (let b=0;b<attrs2.length;b++){ const v2 = n2.getAttribute ? n2.getAttribute(attrs2[b]) : null; if (v2) return v2; }
      }
      cur = cur.parentElement; depth++;
    }
  } catch(e){}
  return null;
}

// ===== selector overlay =====
let ov=null, outline=null, label=null, picking=false, currentEl=null;
function ensureOverlay(){
  if (ov) return;
  ov = document.createElement("div"); ov.id = "cpe-overlay";
  ov.innerHTML = '<div class="cpe-outline"></div><div class="cpe-label">点击以选择聊天容器，按 ESC 取消</div>';
  document.documentElement.appendChild(ov);
  outline = ov.querySelector(".cpe-outline"); label = ov.querySelector(".cpe-label");
}
function updateOutline(el){
  const r = el.getBoundingClientRect();
  outline.style.left = (Math.max(0, r.left + window.scrollX)) + "px";
  outline.style.top = (Math.max(0, r.top + window.scrollY)) + "px";
  outline.style.width = r.width + "px";
  outline.style.height = r.height + "px";
  label.textContent = "选择: " + el.tagName.toLowerCase() + (el.id ? "#" + el.id : "");
}
function onMove(e){
  if (!picking) return;
  const el = document.elementFromPoint(e.clientX, e.clientY);
  if (el && el !== document.documentElement && el !== document.body) { currentEl = el; updateOutline(el); }
}
function onClick(e){
  if (!picking) return;
  e.preventDefault(); e.stopPropagation();
  picking = false;
  document.removeEventListener("mousemove", onMove, true);
  document.removeEventListener("click", onClick, true);
  document.removeEventListener("keydown", onKey, true);
  if (ov) { ov.remove(); ov=null; outline=null; label=null; }
  const selector = cssPath(currentEl);
  window.postMessage({ source:"CPE_SELECTOR", type:"CONTAINER_PICKED", selector: selector }, "*");
}
function onKey(e){
  if (e.key === "Escape") {
    picking = false;
    document.removeEventListener("mousemove", onMove, true);
    document.removeEventListener("click", onClick, true);
    document.removeEventListener("keydown", onKey, true);
    if (ov) { ov.remove(); ov=null; outline=null; label=null; }
    window.postMessage({ source:"CPE_SELECTOR", type:"CANCEL" }, "*");
  }
}
function startPicking(){
  ensureOverlay(); picking = true;
  document.addEventListener("mousemove", onMove, true);
  document.addEventListener("click", onClick, true);
  document.addEventListener("keydown", onKey, true);
}

// ===== extractor =====
const LINKEDIN_NODE_SEL = "li.msg-s-event-listitem, div.msg-s-message-group__message, div.msg-s-event-listitem__message-bubble";
const GENERIC_NODE_SEL  = "[role='listitem'], [data-message], [data-testid*='message'], .message, .msg, .chat-message, .bubble, .im_message, .Message, .c-message_kit__message";

function diagnostics(container){
  const out = {};
  try {
    out.containerExists = !!container;
    if (!container) return out;
    out.hostname = location.hostname;
    out.linkedin = /(^|\.)linkedin\.com$/.test(location.hostname);
    out.counts = {
      linkedinNodes: container.querySelectorAll(LINKEDIN_NODE_SEL).length,
      genericNodes: container.querySelectorAll(GENERIC_NODE_SEL).length
    };
    const sample = Array.from(container.querySelectorAll(LINKEDIN_NODE_SEL)).slice(0,3).map(n => (n.textContent||"").trim().slice(0,80));
    if (sample.length) out.sample = sample;
  } catch(e){ out.diagError = String(e); }
  return out;
}
function guessMessageNodes(container){
  try {
    if (/(^|\.)linkedin\.com$/.test(location.hostname)) {
      const li = container.querySelectorAll(LINKEDIN_NODE_SEL);
      if (li.length) return Array.from(li);
    }
  } catch(e){ console.debug("[CPE] guessMessageNodes linkedin branch error:", e); }
  const candidates = container.querySelectorAll(GENERIC_NODE_SEL);
  if (candidates.length) return Array.from(candidates);
  return Array.from(container.children).filter(n => (n.textContent||"").trim().length > 0);
}
function robustFindTimestamp(el){
  const liTime = el.querySelector("time[datetime], time, span.msg-s-message-group__timestamp, abbr[title]");
  if (liTime){
    const dt = liTime.getAttribute("datetime") || liTime.getAttribute("title") || liTime.textContent;
    if (dt) return sanitizeText(dt);
  }
  const liAttr = el.getAttribute && el.getAttribute("data-time");
  if (liAttr) return liAttr;
  const t2 = el.querySelector("[data-timestamp], [data-time], [data-utime]");
  if (t2){
    const v = t2.getAttribute("data-timestamp") || t2.getAttribute("data-time") || t2.getAttribute("data-utime");
    if (v) return v;
  }
  const labeled = (el.getAttribute && el.getAttribute("aria-label")) || "";
  if (/\d{1,4}[:\/.\-]\d{1,2}/.test(labeled)) return labeled;
  const text = el.textContent; const m = text && text.match(/\b(\d{1,2}:\d{2}(?:\s?[AP]M)?)\b/); if (m) return m[0];
  const nearAttr = nearestAttrBySelectors(el, [
    ["time[datetime]", ["datetime","title"]],
    ["abbr[title]", ["title"]],
    ["span.msg-s-message-group__timestamp", []]
  ], 4);
  if (nearAttr) return sanitizeText(nearAttr);
  const nearText = nearestTextBySelectors(el, ["time","span.msg-s-message-group__timestamp","[aria-label*='AM']","[aria-label*='PM']"], 4);
  if (nearText) return sanitizeText(nearText);
  return null;
}
function robustFindSender(el){
  const liSender = el.querySelector("a.msg-s-message-group__profile-link, span.msg-s-message-group__name, span[dir][data-anonymize], [data-control-name='speaker_name']");
  if (liSender) return sanitizeText(liSender.textContent || "");
  const s = el.querySelector(".sender, .author, .from, .nickname, .name, [data-author], [data-sender], [aria-label*='来自']");
  if (s) return sanitizeText(s.textContent || s.getAttribute("aria-label") || "");
  const near = nearestTextBySelectors(el, [
    "a.msg-s-message-group__profile-link",
    "span.msg-s-message-group__name",
    ".msg-s-message-group__meta",
    ".msg-conversation-head__title",
    ".chat-title, .conversation-title, header h1, header h2"
  ], 4);
  if (near) return sanitizeText(near);
  return null;
}
function extractAttachments(el){
  const list = [];
  const medias = el.querySelectorAll("img, video, audio, a[download], a[href]");
  for (const m of medias) {
    if (m.tagName === "IMG") { list.push({ type:"image", url: toAbsoluteUrl(m.currentSrc || m.src) }); }
    else if (m.tagName === "VIDEO") {
      const source = m.querySelector("source");
      const src = m.currentSrc || (source && source.src) || m.src;
      if (src) list.push({ type:"video", url: toAbsoluteUrl(src) });
    } else if (m.tagName === "A") {
      const href = m.getAttribute("href"); if (!href) continue;
      const abs = toAbsoluteUrl(href);
      const isMedia = /\.(png|jpe?g|gif|webp|svg|mp4|mov|webm|mp3|wav|ogg|pdf)(\?|$)/i.test(abs);
      list.push({ type: isMedia ? "file/media" : "file", url: abs, name: (m.textContent||'').trim() || undefined });
    } else if (m.tagName === "AUDIO") {
      const source = m.querySelector("source");
      const src = m.currentSrc || (source && source.src) || m.src;
      if (src) list.push({ type:"audio", url: toAbsoluteUrl(src) });
    }
  }
  const seen = new Set();
  return list.filter(x => { const k = x.type + "|" + x.url; if (seen.has(k)) return false; seen.add(k); return true; });
}
function extractFromContainer(container){
  try {
    const nodes = guessMessageNodes(container);
    if (!nodes || !nodes.length) {
      console.error("[CPE][CPE_ERR_NO_MESSAGES] 容器内未找到消息节点。", diagnostics(container));
      return { count:0, messages:[], __code:"CPE_ERR_NO_MESSAGES" };
    }
    let lastSender = null, lastTs = null;
    const messages = nodes.map(function(node, idx){
      let text = sanitizeText(node.textContent || "");
      let html = node.innerHTML;
      let timestamp = robustFindTimestamp(node);
      let sender = robustFindSender(node);
      const attachments = extractAttachments(node);
      if (!sender && lastSender) sender = lastSender; else if (sender) lastSender = sender;
      if (!timestamp && lastTs) timestamp = lastTs; else if (timestamp) lastTs = timestamp;
      return { index: idx, sender: sender, text: text, html: html, timestamp: timestamp, attachments: attachments };
    }).filter(function(m){ return (m.text && m.text.length) || (m.attachments && m.attachments.length); });
    return { count: messages.length, messages: messages };
  } catch (e) {
    console.error("[CPE][CPE_ERR_EXTRACT_EXCEPTION] 提取过程中异常：", e);
    return { count:0, messages:[], __code:"CPE_ERR_EXTRACT_EXCEPTION", __err:String(e) };
  }
}

// ===== content state/messages =====
const state = { containerSelector: null, lastExtract: null };

function autoDetectContainer(){
  const found = document.querySelector([
    "ul.msg-s-message-list-content",
    "div.msg-s-message-list-content",
    "section.msg-s-message-list",
    "div.msg-conversation__container",
    "main[role='main'] .msg-convo-wrapper",
    "div .msg-s-message-list__events-list"
  ].join(","));
  if (found) return found;
  return document.querySelector("[role='list'], .chat-list, .messages, .conversation, .msg-list");
}

// preload saved selector for this origin
(function preloadSavedSelector(){
  const key = "cpe::" + originKey();
  try {
    chrome.storage.sync.get([key], function(res){
      if (res && res[key]) {
        state.containerSelector = res[key];
        console.debug("[CPE] Loaded saved selector:", res[key]);
      }
    });
  } catch (e) {
    console.warn("[CPE] preloadSavedSelector failed", e);
  }
})();

// blob fetch bridge
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse){
  if (msg && msg.source === "CPE_BG" && msg.type === "FETCH_BLOB_TO_DATA_URL") {
    (async function(){
      try {
        const resp = await fetch(msg.url);
        const ct = resp.headers.get('content-type') || 'application/octet-stream';
        const buf = await resp.arrayBuffer();
        const b64 = btoa(String.fromCharCode.apply(null, Array.from(new Uint8Array(buf))));
        var ext = 'bin';
        if (ct.indexOf('png')>=0) ext='png';
        else if (ct.indexOf('jpeg')>=0 || ct.indexOf('jpg')>=0) ext='jpg';
        else if (ct.indexOf('gif')>=0) ext='gif';
        else if (ct.indexOf('webp')>=0) ext='webp';
        else if (ct.indexOf('mp4')>=0) ext='mp4';
        else if (ct.indexOf('webm')>=0) ext='webm';
        else if (ct.indexOf('pdf')>=0) ext='pdf';
        sendResponse({ ok:true, dataUrl: "data:"+ct+";base64,"+b64, ext: ext });
      } catch (err) {
        sendResponse({ ok:false, error:String(err) });
      }
    })();
    return true;
  }

  if (!msg || msg.source !== "CPE_POPUP") return;

  if (msg.type === "START_PICK") {
    startPicking(); sendResponse({ ok:true }); return true;
  }

  if (msg.type === "EXTRACT") {
    (async function(){
      try {
        var container = state.containerSelector ? document.querySelector(state.containerSelector) : null;
        if (!container) {
          container = autoDetectContainer();
          if (container && container.id) state.containerSelector = "#" + container.id;
          console.debug("[CPE] Auto-detected container:", container);
        }
        if (!container) {
          const diag = diagnostics(document.body);
          console.error("[CPE][CPE_ERR_NO_CONTAINER] 未选择或找不到容器。诊断：", diag, "选择器：", state.containerSelector);
          sendResponse({ ok:false, error:"未选择或找不到容器", code:"CPE_ERR_NO_CONTAINER", diag: diag });
          return;
        }
        try { container.scrollTop = container.scrollHeight; await new Promise(function(r){ setTimeout(r, 40); }); } catch (e) {}
        const data = extractFromContainer(container);
        if ((data.__code === "CPE_ERR_NO_MESSAGES") || data.count === 0) {
          const diag2 = diagnostics(container);
          console.error("[CPE][CPE_ERR_NO_MESSAGES] 容器内未找到消息节点。诊断：", diag2, "容器选择器：", state.containerSelector);
          sendResponse({ ok:false, error:"容器内未找到消息节点", code:"CPE_ERR_NO_MESSAGES", diag: diag2 });
          return;
        }
        if (data.__code === "CPE_ERR_EXTRACT_EXCEPTION") {
          console.error("[CPE][CPE_ERR_EXTRACT_EXCEPTION] 异常：", data.__err);
          sendResponse({ ok:false, error:(data.__err || "提取过程中异常"), code:"CPE_ERR_EXTRACT_EXCEPTION" });
          return;
        }
        let __baseTitle = getChatTitle();
        const payload = {
          chatTitle: refineChatTitleWithMessages(__baseTitle, data.messages),
          pageTitle: document.title,
          pageUrl: location.href,
          scrapedAt: nowISO(),
          containerSelector: state.containerSelector,
          count: data.count,
          messages: data.messages
        };
        state.lastExtract = payload;
        console.debug("[CPE] Extracted messages:", payload.count, "chatTitle:", payload.chatTitle);
        sendResponse({ ok:true, payload: payload });
      } catch (e) {
        console.error("[CPE][CPE_ERR_CONTENT_EXCEPTION] 内容脚本异常：", e);
        sendResponse({ ok:false, error:String(e), code:"CPE_ERR_CONTENT_EXCEPTION" });
      }
    })();
    return true;
  }

  if (msg.type === "SET_SELECTOR") {
    state.containerSelector = msg.selector;
    try { chrome.storage.sync.set({ ["cpe::" + originKey()]: state.containerSelector }); } catch (e) {}
    console.debug("[CPE] Selector set to:", state.containerSelector);
    sendResponse({ ok:true });
    return true;
  }
});

window.addEventListener("message", function(e){
  if (e.source !== window) return;
  const data = e.data || {}; if (data.source !== "CPE_SELECTOR") return;
  if (data.type === "CONTAINER_PICKED") {
    state.containerSelector = data.selector;
    try { chrome.storage.sync.set({ ["cpe::" + originKey()]: state.containerSelector }); } catch (e) {}
    console.debug("[CPE] Container picked:", data.selector);
    chrome.runtime.sendMessage({ source:"CPE_CONTENT", type:"CONTAINER_PICKED", selector: data.selector });
  }
  if (data.type === "CANCEL") {
    chrome.runtime.sendMessage({ source:"CPE_CONTENT", type:"PICK_CANCELLED" });
  }
});

// ---- Right-side floating panel ----
function ensureSidePanel(){
  if (document.getElementById('cpe-sidepanel')) return;
  const panel = document.createElement('div');
  panel.id = 'cpe-sidepanel';
  panel.innerHTML = `
    <div class="cpe-sp-header">
      <span>Chat Extractor</span>
      <button class="cpe-sp-toggle" title="折叠/展开">⟨</button>
    </div>
    <div class="cpe-sp-body">
      <button class="cpe-sp-btn" data-act="extract" title="快捷键：Ctrl/⌘+Shift+E">提取</button>
      <button class="cpe-sp-btn" data-act="exportMd" title="快捷键：Ctrl/⌘+Shift+M">导出 Markdown</button>
      <div class="cpe-sp-status" id="cpe-sp-status"></div>
    </div>
  `;
  document.documentElement.appendChild(panel);
  const toggle = panel.querySelector('.cpe-sp-toggle');
  toggle.addEventListener('click', () => {
    const collapsed = panel.classList.toggle('collapsed');
    toggle.textContent = collapsed ? '⟩' : '⟨';
  });
  panel.addEventListener('click', async (e) => {
    const b = e.target.closest('.cpe-sp-btn'); if (!b) return;
    const act = b.getAttribute('data-act');
    const status = document.getElementById('cpe-sp-status');
    if (act === 'extract') {
      chrome.runtime.sendMessage({ source:'CPE_POPUP', type:'EXTRACT' }, (res)=>{
        if (!res || !res.ok) { status.textContent = (res && res.error) || '提取失败'; return; }
        status.textContent = `已提取 ${res.payload.count} 条消息`;
      });
    } else if (act === 'exportMd') {
      status.textContent = '导出中…';
      chrome.runtime.sendMessage({ source:'CPE_CONTENT', type:'CMD_EXPORT_MD' }, (r)=>{
        status.textContent = r && r.ok ? '已导出 Markdown' : '导出失败';
      });
    }
  });
}
setTimeout(ensureSidePanel, 800);

})();