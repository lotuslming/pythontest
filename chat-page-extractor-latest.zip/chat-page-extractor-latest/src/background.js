function ab2b64(buf){ var b=''; var a=new Uint8Array(buf); for(var i=0;i<a.length;i++) b+=String.fromCharCode(a[i]); return btoa(b); }
function guessExtFromType(type){
  if(!type) return 'bin';
  if(type.indexOf('png')>=0) return 'png';
  if(type.indexOf('jpeg')>=0||type.indexOf('jpg')>=0) return 'jpg';
  if(type.indexOf('gif')>=0) return 'gif';
  if(type.indexOf('webp')>=0) return 'webp';
  if(type.indexOf('svg')>=0) return 'svg';
  if(type.indexOf('mp4')>=0) return 'mp4';
  if(type.indexOf('webm')>=0) return 'webm';
  if(type.indexOf('quicktime')>=0) return 'mov';
  if(type.indexOf('mp3')>=0) return 'mp3';
  if(type.indexOf('wav')>=0) return 'wav';
  if(type.indexOf('ogg')>=0) return 'ogg';
  if(type.indexOf('pdf')>=0) return 'pdf';
  if(type.indexOf('json')>=0) return 'json';
  if(type.indexOf('plain')>=0) return 'txt';
  return 'bin';
}

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse){
  if (!msg || (msg.source !== "CPE_POPUP" && msg.source !== "CPE_CONTENT")) return;

  if (msg.type === "SAVE_SELECTOR") {
    var origin = msg.origin, selector = msg.selector;
    chrome.storage.sync.set({ ["cpe::" + origin]: selector }, function(){ sendResponse({ ok: true }); });
    return true;
  }
  if (msg.type === "LOAD_SELECTOR") {
    var origin2 = msg.origin;
    chrome.storage.sync.get(["cpe::" + origin2], function(res){ sendResponse({ ok: true, selector: res["cpe::" + origin2] || null }); });
    return true;
  }

  if (msg.type === "DOWNLOAD_ASSETS") {
    (async function(){
      var assets = msg.assets, filePrefix = msg.filePrefix;
      var mapping = {}; var counter = 1;
      var tabs = await chrome.tabs.query({active:true, currentWindow:true});
      var tabId = tabs && tabs[0] && tabs[0].id;
      for (var i=0;i<assets.length;i++) {
        var a = assets[i]; var rawUrl = a.url;
        try {
          var filename = '', dataUrl = '';
          if (rawUrl.indexOf('blob:') === 0 && tabId) {
            var res = await chrome.tabs.sendMessage(tabId, { source:'CPE_BG', type:'FETCH_BLOB_TO_DATA_URL', url: rawUrl });
            if (res && res.ok && res.dataUrl) {
              var ext = res.ext || 'bin';
              filename = filePrefix + '-' + String(counter).padStart(3,'0') + '.' + ext; counter++; dataUrl = res.dataUrl;
            }
          }
          if (!dataUrl) {
            var resp = await fetch(rawUrl, { credentials: 'include' });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            var buf = await resp.arrayBuffer();
            var ct = resp.headers.get('content-type') || '';
            var ext2 = guessExtFromType(ct) || (a.type && a.type.indexOf('image')>=0 ? 'png' : (a.type && a.type.indexOf('video')>=0 ? 'mp4' : 'bin'));
            filename = filename || (filePrefix + '-' + String(counter).padStart(3,'0') + '.' + ext2); counter++;
            var base64 = ab2b64(buf);
            dataUrl = 'data:' + (ct || 'application/octet-stream') + ';base64,' + base64;
          }
          await new Promise(function(resolve){ chrome.downloads.download({ url: dataUrl, filename: filename, conflictAction: 'uniquify' }, function(){ resolve(); }); });
          mapping[rawUrl] = filename;
        } catch (e) { console.warn('[CPE] Download failed (fetch->data)', rawUrl, e); }
      }
      sendResponse({ ok: true, mapping: mapping });
    })();
    return true;
  }
});

async function getActiveTabId(){
  const tabs = await chrome.tabs.query({active:true, currentWindow:true});
  return (tabs && tabs[0] && tabs[0].id) || null;
}
function sanitizeHtmlForMd(html) {
  if (!html) return '';
  html = html.replace(/<\/(script|style)[^>]*>/gi, '').replace(/<(script|style)[^>]*>.*?<\/\1>/gis, '');
  const allowed = ['b','strong','i','em','u','code','pre','br','a','ul','ol','li','blockquote'];
  return html
    .replace(/<([^\s>\/]+)([^>]*)>/gi, (m, tag, attrs) => {
      tag = tag.toLowerCase();
      if (!allowed.includes(tag)) return '';
      if (tag === 'a') {
        const m1 = attrs.match(/href\s*=\s*"([^"]*)"/i);
        const m2 = attrs.match(/href\s*=\s*'([^']*)'/i);
        const m3 = attrs.match(/href\s*=\s*([^\s>]+)/i);
        const href = (m1 && m1[1]) || (m2 && m2[1]) || (m3 && m3[1]) || '';
        return href ? `<a href="${href}">` : '<a>';
      }
      return `<${tag}>`;
    })
    .replace(/<\/(?!b|strong|i|em|u|code|pre|a|ul|ol|li|blockquote)\w+>/gi, '');
}
function embedAttachment(a){
  const href = a.href || a.url;
  if (!href) return null;
  if (/\.png$|\.jpe?g$|\.gif$|\.webp$|\.svg$/i.test(href)) return `![](${href})`;
  if (/\.mp4$|\.webm$|\.mov$/i.test(href)) return `<video src="${href}" controls></video>`;
  if (/\.mp3$|\.wav$|\.ogg$/i.test(href)) return `<audio src="${href}" controls></audio>`;
  const label = a.name || href;
  return `[${label}](${href})`;
}
async function exportMarkdownFromTab(tabId){
  if (!tabId) tabId = await getActiveTabId();
  if (!tabId) return;
  const res = await chrome.tabs.sendMessage(tabId, { source:'CPE_POPUP', type:'EXTRACT' });
  if (!res || !res.ok || !res.payload) { console.error('[CPE][BG] 导出前提取失败：', res); return; }
  const data = res.payload;
  const ts = new Date().toISOString().replaceAll(':','-');
  const chatTitle = (data.chatTitle || 'chat').replace(/[:*?"<>|\\\/]/g,"-").trim().slice(0,80) || 'chat';
  const exportBase = `chat-${chatTitle}-${ts}`;
  const assetsPrefix = `${exportBase}/assets/asset`;
  const assets = []; for (const m of data.messages) { for (const a of m.attachments) assets.push(a); }
  const resDl = await new Promise(resolve => chrome.runtime.sendMessage({ source:'CPE_CONTENT', type:'DOWNLOAD_ASSETS', assets, filePrefix: assetsPrefix }, resolve));
  const mapping = (resDl && resDl.mapping) || {};
  for (const m of data.messages) {
    for (const a of m.attachments) {
      a.localFile = mapping[a.url] || null;
      a.href = a.localFile ? a.localFile.replace(exportBase + "/", "") : a.url;
    }
  }
  const lines = [];
  lines.push(`# 导出对话 — ${data.pageTitle || ''}`.trim());
  lines.push('');
  lines.push(`- 页面：${data.pageUrl}`);
  lines.push(`- 抓取时间：${data.scrapedAt}`);
  lines.push(`- 会话：${data.chatTitle || ''}`);
  lines.push(`- 容器：\`${data.containerSelector || '(自动)'}\``);
  lines.push(`- 条数：${data.count}`);
  lines.push(''); lines.push('---'); lines.push('');
  for (const m of data.messages) {
    const who = m.sender ? `**${m.sender}**` : '**(未知发送者)**';
    const ts2 = m.timestamp ? ` <sub>${m.timestamp}</sub>` : '';
    const plain = (m.text || '').replace(/\r?\n/g, '  \\n');
    const keptHtml = sanitizeHtmlForMd(m.html);
    const main = keptHtml ? `${plain}\n\n${keptHtml}` : plain;
    lines.push(`- ${who}${ts2}: ${main}`);
    if (m.attachments && m.attachments.length) {
      for (const a of m.attachments) {
        const embed = embedAttachment(a);
        if (embed) lines.push(`  - ${embed}`);
      }
    }
  }
  const mdName = `${exportBase}/chat-export.md`; const mdText = lines.join('\n');
  const url = URL.createObjectURL(new Blob([mdText], { type: 'text/markdown' }));
  await new Promise(resolve => chrome.downloads.download({ url, filename: mdName, conflictAction: 'uniquify', saveAs: false }, () => resolve()));
}
chrome.commands.onCommand.addListener(async (command) => {
  try {
    const tabId = await getActiveTabId();
    if (!tabId) return;
    if (command === 'cpe-extract') {
      const res = await chrome.tabs.sendMessage(tabId, { source:'CPE_POPUP', type:'EXTRACT' });
      console.debug('[CPE][BG] 快捷键提取：', res && res.ok ? ('OK, '+res.payload.count) : res);
    } else if (command === 'cpe-export-md') {
      await exportMarkdownFromTab(tabId);
    }
  } catch(e){ console.error('[CPE][BG] commands error', e); }
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
  if (msg && msg.source==='CPE_CONTENT' && msg.type==='CMD_EXPORT_MD') {
    (async()=>{ await exportMarkdownFromTab((sender && sender.tab && sender.tab.id) || null); sendResponse({ok:true}); })();
    return true;
  }
});
