
// Utility helpers used across content/selector/extractor
export function nowISO() {
  return new Date().toISOString();
}

export function domainKey(url) {
  try { return new URL(url).origin; } catch { return "*"; }
}

export function createFileName(prefix, ext = "json") {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  return `${prefix}-${stamp}.${ext}`;
}

export function cssPath(el) {
  // Build a robust CSS selector path
  if (!el || el.nodeType !== 1) return "";
  const path = [];
  while (el && el.nodeType === 1 && el !== document.documentElement) {
    let selector = el.nodeName.toLowerCase();
    if (el.id) {
      selector += `#${CSS.escape(el.id)}`;
      path.unshift(selector);
      break; // IDs are unique; good enough
    }
    // Prefer class hints when short and meaningful
    const cls = [...el.classList].filter(c => c.length <= 32).slice(0, 3);
    if (cls.length) selector += "." + cls.map(c => CSS.escape(c)).join(".");

    // nth-of-type to stabilize
    const parent = el.parentNode;
    if (parent) {
      const tag = el.tagName;
      const siblings = [...parent.children].filter(n => n.tagName === tag);
      if (siblings.length > 1) {
        const idx = siblings.indexOf(el) + 1;
        selector += `:nth-of-type(${idx})`;
      }
    }
    path.unshift(selector);
    el = el.parentElement;
  }
  return path.join(" > ");
}

export function sanitizeText(t) {
  return t.replace(/\s+/g, " ").trim();
}

export function toAbsoluteUrl(u) {
  try { return new URL(u, location.href).href; } catch { return u; }
}
