
import { startPicking } from "./selector.js";
import { extractFromContainer } from "./extractor.js";
import { nowISO } from "./util.js";

const state = {
  containerSelector: null,
  lastExtract: null,
  lastJson: null,
};

// Listen for popup and background commands
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // From background: fetch a blob: URL in page context and return data URL
  if (msg?.source === 'CPE_BG' && msg.type === 'FETCH_BLOB_TO_DATA_URL') {
    (async () => {
      try {
        const resp = await fetch(msg.url);
        const ct = resp.headers.get('content-type') || 'application/octet-stream';
        const buf = await resp.arrayBuffer();
        const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
        let ext = 'bin';
        if (ct.includes('png')) ext = 'png';
        else if (ct.includes('jpeg') || ct.includes('jpg')) ext = 'jpg';
        else if (ct.includes('gif')) ext = 'gif';
        else if (ct.includes('webp')) ext = 'webp';
        else if (ct.includes('mp4')) ext = 'mp4';
        else if (ct.includes('webm')) ext = 'webm';
        else if (ct.includes('pdf')) ext = 'pdf';
        sendResponse({ ok: true, dataUrl: `data:${ct};base64,${b64}`, ext });
      } catch (err) {
        sendResponse({ ok: false, error: String(err) });
      }
    })();
    return true; // keep channel open
  }

  if (msg?.source !== "CPE_POPUP") return;

  if (msg.type === "START_PICK") {
    startPicking();
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === "EXTRACT") {
    const container = state.containerSelector ? document.querySelector(state.containerSelector) : null;
    if (!container) return sendResponse({ ok: false, error: "未选择或找不到容器" });

    const data = extractFromContainer(container);
    const payload = {
      pageTitle: document.title,
      pageUrl: location.href,
      scrapedAt: nowISO(),
      containerSelector: state.containerSelector,
      ...data,
    };
    state.lastExtract = payload;
    sendResponse({ ok: true, payload });
    return true;
  }
  if (msg.type === "SET_SELECTOR") {
    state.containerSelector = msg.selector;
    sendResponse({ ok: true });
    return true;
  }
});

// Bridge events from selector overlay back to popup
window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  const data = e.data || {};
  if (data.source !== "CPE_SELECTOR") return;

  if (data.type === "CONTAINER_PICKED") {
    state.containerSelector = data.selector;
    chrome.runtime.sendMessage({ source: "CPE_CONTENT", type: "CONTAINER_PICKED", selector: data.selector });
  }
  if (data.type === "CANCEL") {
    chrome.runtime.sendMessage({ source: "CPE_CONTENT", type: "PICK_CANCELLED" });
  }
});
