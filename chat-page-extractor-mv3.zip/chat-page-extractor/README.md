
# Chat Page Extractor (MV3)

功能：
- 在网页上**选择聊天窗口容器**
- **自动提取**聊天文本、HTML、时间戳、发送者
- **抓取并下载**消息中的图片/视频/文件（已改为 **fetch -> data:** 模式，支持带登录态请求；同时对 `blob:` 链接做了回退）
- 一键导出 **JSON** 或 **Markdown（保留少量安全富文本）** 到本地

## 安装
1. 将本项目保存为文件夹 `chat-page-extractor/`。
2. 打开 Chrome → 访问 `chrome://extensions/`。
3. 右上角打开 **开发者模式**。
4. 点击 **加载已解压的扩展程序** → 选择该文件夹。

## 使用
1. 打开含有聊天的网页（支持 linkedin.com/messaging 更佳识别）。
2. 点击扩展图标，点 **“选择聊天容器”**，在页面中点击聊天区域最外层容器（推荐：LinkedIn 选 `div.msg-s-message-list-content`）。
3. 弹窗中会填入容器 CSS 选择器，可手动调整并 **保存**（按站点记忆）。
4. 点击 **“提取”** → 确认条数。
5. 勾选是否 **下载图片/文件/视频**（默认开启）。
6. 点击 **“导出 JSON”** 或 **“导出 Markdown”**。

## JSON 结构
见 `messages[].{sender,text,html,timestamp,attachments[]}`。附件在下载后会写入 `localFile` 与 `href` 字段。

## Markdown 富文本白名单
允许标签：`b,strong,i,em,u,code,pre,br,a,ul,ol,li,blockquote`。其他标签将被移除；`<a>` 仅保留 `href`。

## 注意
- 某些站点使用虚拟列表（仅渲染可见部分），**请先滚动加载完全** 再提取。\n- 若资源为受限 `blob:` URL，后台会让内容脚本在页面上下文 `fetch`，再转为 `data:` 下载，提高成功率。\n- 此扩展仅供个人归档备份使用，注意遵守各站点服务条款与隐私政策。
