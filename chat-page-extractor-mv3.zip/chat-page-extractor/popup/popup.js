
const statusEl = document.getElementById('status');
const selectorInput = document.getElementById('selector');
const downloadAssetsEl = document.getElementById('downloadAssets');
const exportMdBtn = document.getElementById('exportMd');

function setStatus(msg) { statusEl.textContent = msg; }

function getActiveTab() {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => resolve(tabs[0]));
  });
}

(async function init() {
  const tab = await getActiveTab();
  const origin = new URL(tab.url).origin;
  chrome.runtime.sendMessage({ source: 'CPE_POPUP', type: 'LOAD_SELECTOR', origin }, (res) => {
    if (res?.selector) selectorInput.value = res.selector;
  });
})();

async function sendToTab(msg) {
  const tab = await getActiveTab();
  return new Promise(resolve => chrome.tabs.sendMessage(tab.id, { source: 'CPE_POPUP', ...msg }, resolve));
}

document.getElementById('pick').addEventListener('click', async () => {
  await sendToTab({ type: 'START_PICK' });
  setStatus('请在页面上点击聊天容器…');
});

document.getElementById('save').addEventListener('click', async () => {
  const tab = await getActiveTab();
  const origin = new URL(tab.url).origin;
  const selector = selectorInput.value.trim();
  chrome.runtime.sendMessage({ source: 'CPE_POPUP', type: 'SAVE_SELECTOR', origin, selector }, () => setStatus('已保存到此站点。'));
  await sendToTab({ type: 'SET_SELECTOR', selector });
});

document.getElementById('extract').addEventListener('click', async () => {
  const selector = selectorInput.value.trim();
  if (!selector) return setStatus('请先选择或填写容器选择器');
  await sendToTab({ type: 'SET_SELECTOR', selector });
  const res = await sendToTab({ type: 'EXTRACT' });
  if (!res?.ok) return setStatus(res?.error || '提取失败');
  window.__lastData = res.payload;
  setStatus(`已提取 ${res.payload.count} 条消息`);
});

function downloadJSON(data, filename) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename, conflictAction: 'uniquify', saveAs: true });
}

function downloadMarkdown(md, filename) {
  const blob = new Blob([md], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename, conflictAction: 'uniquify', saveAs: true });
}

// 允许少量安全的内联 HTML 进入 Markdown（白名单）
function sanitizeHtmlForMd(html) {
  if (!html) return '';
  // 移除危险标签
  html = html.replace(/<\/(script|style)[^>]*>/gi, '').replace(/<(script|style)[^>]*>.*?<\/\1>/gis, '');
  // 仅保留以下标签与属性
  const allowedTags = ['b','strong','i','em','u','code','pre','br','a','ul','ol','li','blockquote'];
  return html.replace(/<([^\s>/]+)([^>]*)>/gi, (m, tag, attrs) => {
    tag = tag.toLowerCase();
    if (!allowedTags.includes(tag)) return '';
    if (tag === 'a') {
      const m1 = attrs.match(/href\s*=\s*"([^"]*)"/i);
      const m2 = attrs.match(/href\s*=\s*'([^']*)'/i);
      const m3 = attrs.match(/href\s*=\s*([^\s>]+)/i);
      const href = (m1 && m1[1]) || (m2 && m2[1]) || (m3 && m3[1]) || '';
      if (!href) return `<a>`; // 裸标签
      return `<a href="${href}">`;
    }
    return `<${tag}>`;
  }).replace(/<\/(?!b|strong|i|em|u|code|pre|a|ul|ol|li|blockquote)\w+>/gi, '');
}

// JSON 导出（含 fetch->data 后的本地文件名回填由后台完成）
document.getElementById('export').addEventListener('click', async () => {
  const data = window.__lastData;
  if (!data) return setStatus('请先点击“提取”');

  const filePrefix = `chat-export`;
  const shouldDownload = downloadAssetsEl.checked;

  if (shouldDownload) {
    const assets = [];
    for (const m of data.messages) {
      for (const a of m.attachments) assets.push(a);
    }
    const res = await new Promise(resolve => {
      chrome.runtime.sendMessage({ source: 'CPE_POPUP', type: 'DOWNLOAD_ASSETS', assets, filePrefix }, resolve);
    });
    const mapping = res?.mapping || {};
    for (const m of data.messages) {
      for (const a of m.attachments) {
        a.localFile = mapping[a.url] || null;
        a.href = a.localFile ? a.localFile : a.url;
      }
    }
  } else {
    for (const m of data.messages) {
      for (const a of m.attachments) a.href = a.url;
    }
  }

  const filename = `chat-export-${new Date().toISOString().replaceAll(':','-')}.json`;
  downloadJSON(data, filename);
  setStatus('已导出 JSON');
});

// Markdown 导出（保留少量安全富文本）
exportMdBtn.addEventListener('click', async () => {
  const data = window.__lastData;
  if (!data) return setStatus('请先点击“提取”');

  const lines = [];
  lines.push(`# 导出对话 — ${data.pageTitle || ''}`.trim());
  lines.push('');
  lines.push(`- 页面：${data.pageUrl}`);
  lines.push(`- 抓取时间：${data.scrapedAt}`);
  lines.push(`- 容器：\`${data.containerSelector}\``);
  lines.push(`- 条数：${data.count}`);
  lines.push('');
  lines.push('---');
  lines.push('');

  for (const m of data.messages) {
    const who = m.sender ? `**${m.sender}**` : '**(未知发送者)**';
    const ts = m.timestamp ? ` <sub>${m.timestamp}</sub>` : '';
    const plain = (m.text || '').replace(/\r?\n/g, '  \\n');
    const keptHtml = sanitizeHtmlForMd(m.html);
    const line = keptHtml ? `${plain}\n\n${keptHtml}` : plain;
    lines.push(`- ${who}${ts}: ${line}`);

    if (m.attachments && m.attachments.length) {
      for (const a of m.attachments) {
        const label = a.name || a.localFile || a.url;
        const href = a.href || a.url;
        lines.push(`  - 附件（${a.type}）：[${label}](${href})`);
      }
    }
  }

  const md = lines.join('\n');
  const filename = `chat-export-${new Date().toISOString().replaceAll(':','-')}.md`;
  downloadMarkdown(md, filename);
  setStatus('已导出 Markdown');
});

// Listen for container pick result coming from content.js
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.source !== 'CPE_CONTENT') return;
  if (msg.type === 'CONTAINER_PICKED') {
    selectorInput.value = msg.selector;
    setStatus('已选择容器');
  }
  if (msg.type === 'PICK_CANCELLED') setStatus('已取消选择');
});
