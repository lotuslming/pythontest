
import { startPicking } from "./selector.js";
import { extractFromContainer, diagnostics } from "./extractor.js";
import { nowISO } from "./util.js";

const state = { containerSelector: null, lastExtract: null };

function originKey() { try { return new URL(location.href).origin; } catch { return "*"; } }

async function loadSavedSelector() {
  const key = "cpe::" + originKey();
  return new Promise(resolve => {
    try { chrome.storage.sync.get([key], (res) => resolve(res[key] || null)); }
    catch { resolve(null); }
  });
}

function autoDetectContainer() {
  const found = document.querySelector([
    "ul.msg-s-message-list-content",
    "div.msg-s-message-list-content",
    "section.msg-s-message-list",
    "div.msg-conversation__container",
    "main[role='main'] .msg-convo-wrapper",
    "div .msg-s-message-list__events-list"
  ].join(","));
  if (found) return found;
  return document.querySelector("[role='list'], .chat-list, .messages, .conversation, .msg-list");
}

loadSavedSelector().then(sel => { if (sel) { state.containerSelector = sel; console.debug("[CPE] Loaded saved selector:", sel); } });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // background asks us to fetch blob: and return data url
  if (msg?.source === 'CPE_BG' && msg.type === 'FETCH_BLOB_TO_DATA_URL') {
    (async () => {
      try {
        const resp = await fetch(msg.url);
        const ct = resp.headers.get('content-type') || 'application/octet-stream';
        const buf = await resp.arrayBuffer();
        const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
        let ext = 'bin';
        if (ct.includes('png')) ext = 'png';
        else if (ct.includes('jpeg') || ct.includes('jpg')) ext = 'jpg';
        else if (ct.includes('gif')) ext = 'gif';
        else if (ct.includes('webp')) ext = 'webp';
        else if (ct.includes('mp4')) ext = 'mp4';
        else if (ct.includes('webm')) ext = 'webm';
        else if (ct.includes('pdf')) ext = 'pdf';
        sendResponse({ ok: true, dataUrl: `data:${ct};base64,${b64}`, ext });
      } catch (err) { sendResponse({ ok: false, error: String(err) }); }
    })(); return true;
  }

  if (msg?.source !== "CPE_POPUP") return;

  if (msg.type === "START_PICK") { startPicking(); sendResponse({ ok: true }); return true; }

  if (msg.type === "EXTRACT") {
    try {
      let container = state.containerSelector ? document.querySelector(state.containerSelector) : null;
      if (!container) {
        container = autoDetectContainer();
        if (container && container.id) state.containerSelector = `#${container.id}`;
        console.debug("[CPE] Auto-detected container:", container);
      }
      if (!container) {
        const diag = diagnostics(document.body);
        console.error("[CPE][CPE_ERR_NO_CONTAINER] 未选择或找不到容器。诊断：", diag, "选择器：", state.containerSelector);
        return sendResponse({ ok: false, error: "未选择或找不到容器", code: "CPE_ERR_NO_CONTAINER", diag });
      }

      // Light scroll to help virtual lists render (best-effort)
      try { container.scrollTop = container.scrollHeight; await new Promise(r => setTimeout(r, 40)); } catch {}

      const data = extractFromContainer(container);
      if ((data.__code === "CPE_ERR_NO_MESSAGES") || data.count === 0) {
        const diag = diagnostics(container);
        console.error("[CPE][CPE_ERR_NO_MESSAGES] 容器内未找到消息节点。诊断：", diag, "容器选择器：", state.containerSelector);
        return sendResponse({ ok: false, error: "容器内未找到消息节点", code: "CPE_ERR_NO_MESSAGES", diag });
      }
      if (data.__code === "CPE_ERR_EXTRACT_EXCEPTION") {
        console.error("[CPE][CPE_ERR_EXTRACT_EXCEPTION] 异常：", data.__err);
        return sendResponse({ ok: false, error: data.__err || "提取过程中异常", code: "CPE_ERR_EXTRACT_EXCEPTION" });
      }

      const payload = { pageTitle: document.title, pageUrl: location.href, scrapedAt: nowISO(), containerSelector: state.containerSelector, ...data };
      state.lastExtract = payload;
      console.debug("[CPE] Extracted messages:", payload.count);
      sendResponse({ ok: true, payload }); return true;
    } catch (e) {
      console.error("[CPE][CPE_ERR_CONTENT_EXCEPTION] 内容脚本异常：", e);
      sendResponse({ ok: false, error: String(e), code: "CPE_ERR_CONTENT_EXCEPTION" });
      return true;
    }
  }

  if (msg.type === "SET_SELECTOR") {
    state.containerSelector = msg.selector;
    try { chrome.storage.sync.set({ ["cpe::" + originKey()]: state.containerSelector }); } catch {}
    console.debug("[CPE] Selector set to:", state.containerSelector);
    sendResponse({ ok: true }); return true;
  }
});

window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  const data = e.data || {}; if (data.source !== "CPE_SELECTOR") return;
  if (data.type === "CONTAINER_PICKED") {
    state.containerSelector = data.selector;
    try { chrome.storage.sync.set({ ["cpe::" + originKey()]: state.containerSelector }); } catch {}
    console.debug("[CPE] Container picked:", data.selector);
    chrome.runtime.sendMessage({ source: "CPE_CONTENT", type: "CONTAINER_PICKED", selector: data.selector });
  }
  if (data.type === "CANCEL") chrome.runtime.sendMessage({ source: "CPE_CONTENT", type: "PICK_CANCELLED" });
});
