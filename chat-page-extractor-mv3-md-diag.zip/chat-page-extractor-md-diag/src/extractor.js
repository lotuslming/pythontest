
import { sanitizeText, toAbsoluteUrl } from "./util.js";

const LINKEDIN_NODE_SEL = "li.msg-s-event-listitem, div.msg-s-message-group__message, div.msg-s-event-listitem__message-bubble";
const GENERIC_NODE_SEL = "[role='listitem'], [data-message], [data-testid*='message'], .message, .msg, .chat-message, .bubble, .im_message, .Message, .c-message_kit__message";

export function diagnostics(container) {
  const out = {};
  try {
    out.containerExists = !!container;
    if (!container) return out;
    out.hostname = location.hostname;
    out.linkedin = /(^|\.)linkedin\.com$/.test(location.hostname);
    out.counts = {
      linkedinNodes: container.querySelectorAll(LINKEDIN_NODE_SEL).length,
      genericNodes: container.querySelectorAll(GENERIC_NODE_SEL).length
    };
    // sample first few text snippets to validate
    const sample = [...container.querySelectorAll(LINKEDIN_NODE_SEL)].slice(0, 3).map(n => (n.textContent||"").trim().slice(0,80));
    if (sample.length) out.sample = sample;
  } catch (e) { out.diagError = String(e); }
  return out;
}

function guessMessageNodes(container) {
  // LinkedIn first
  try {
    if (/(^|\.)linkedin\.com$/.test(location.hostname)) {
      const li = container.querySelectorAll(LINKEDIN_NODE_SEL);
      if (li.length) return [...li];
    }
  } catch (e) { console.debug("[CPE] guessMessageNodes linkedin branch error:", e); }
  const candidates = container.querySelectorAll(GENERIC_NODE_SEL);
  if (candidates.length) return [...candidates];
  return [...container.children].filter(n => (n.textContent||"").trim().length > 0);
}

function findTimestamp(el) {
  const liTime = el.querySelector("time[datetime], time, span.msg-s-message-group__timestamp");
  if (liTime) {
    const dt = liTime.getAttribute("datetime") || liTime.getAttribute("title") || liTime.textContent;
    if (dt) return sanitizeText(dt);
  }
  const liAttr = el.getAttribute("data-time");
  if (liAttr) return liAttr;
  const t1 = el.querySelector("time[datetime]"); if (t1) return t1.getAttribute("datetime");
  const t2 = el.querySelector("[data-timestamp], [data-time], [data-utime]");
  if (t2) return t2.getAttribute("data-timestamp") || t2.getAttribute("data-time") || t2.getAttribute("data-utime");
  const labeled = el.getAttribute("aria-label") || "";
  if (/\d{1,4}[:\/.\-]\d{1,2}/.test(labeled)) return labeled;
  const text = el.textContent;
  const timeLike = text && text.match(/\b(\d{1,2}:\d{2}(?:\s?[AP]M)?)\b/);
  if (timeLike) return timeLike[0];
  return null;
}

function findSender(el) {
  const liSender = el.querySelector("a.msg-s-message-group__profile-link, span.msg-s-message-group__name, span[dir][data-anonymize]");
  if (liSender) return sanitizeText(liSender.textContent || "");
  const s = el.querySelector(".sender, .author, .from, .nickname, .name, [data-author], [data-sender], [aria-label*='来自']");
  if (!s) return null;
  return sanitizeText(s.textContent || s.getAttribute("aria-label") || "");
}

function extractAttachments(el) {
  const list = [];
  const medias = el.querySelectorAll("img, video, audio, a[download], a[href]");
  for (const m of medias) {
    if (m.tagName === "IMG") list.push({ type: "image", url: toAbsoluteUrl(m.currentSrc || m.src) });
    else if (m.tagName === "VIDEO") {
      const src = m.currentSrc || (m.querySelector("source")?.src) || m.src;
      if (src) list.push({ type: "video", url: toAbsoluteUrl(src) });
    } else if (m.tagName === "A") {
      const href = m.getAttribute("href"); if (!href) continue;
      const abs = toAbsoluteUrl(href);
      const isMedia = /\.(png|jpe?g|gif|webp|svg|mp4|mov|webm|mp3|wav|ogg)(\?|$)/i.test(abs);
      list.push({ type: isMedia ? "file/media" : "file", url: abs, name: (m.textContent||'').trim() || undefined });
    } else if (m.tagName === "AUDIO") {
      const src = m.currentSrc || (m.querySelector("source")?.src) || m.src;
      if (src) list.push({ type: "audio", url: toAbsoluteUrl(src) });
    }
  }
  const seen = new Set();
  return list.filter(x => { const k = `${x.type}|${x.url}`; if (seen.has(k)) return false; seen.add(k); return true; });
}

export function extractFromContainer(container) {
  try {
    const nodes = guessMessageNodes(container);
    if (!nodes || !nodes.length) {
      console.error("[CPE][CPE_ERR_NO_MESSAGES] 容器内未找到消息节点。", diagnostics(container));
      return { count: 0, messages: [] , __code: "CPE_ERR_NO_MESSAGES" };
    }
    const messages = nodes.map((node, idx) => {
      const text = sanitizeText(node.textContent || "");
      const html = node.innerHTML;
      const timestamp = findTimestamp(node);
      const sender = findSender(node);
      const attachments = extractAttachments(node);
      return { index: idx, sender, text, html, timestamp, attachments };
    }).filter(m => (m.text && m.text.length) || (m.attachments && m.attachments.length));
    return { count: messages.length, messages };
  } catch (e) {
    console.error("[CPE][CPE_ERR_EXTRACT_EXCEPTION] 提取过程中异常：", e);
    return { count: 0, messages: [], __code: "CPE_ERR_EXTRACT_EXCEPTION", __err: String(e) };
  }
}
