
function ab2b64(buf){ let b=''; const a=new Uint8Array(buf); for(let i=0;i<a.length;i++) b+=String.fromCharCode(a[i]); return btoa(b); }
function guessExtFromType(type){
  if(!type) return 'bin';
  if(type.includes('png')) return 'png';
  if(type.includes('jpeg')||type.includes('jpg')) return 'jpg';
  if(type.includes('gif')) return 'gif';
  if(type.includes('webp')) return 'webp';
  if(type.includes('svg')) return 'svg';
  if(type.includes('mp4')) return 'mp4';
  if(type.includes('webm')) return 'webm';
  if(type.includes('quicktime')) return 'mov';
  if(type.includes('mp3')) return 'mp3';
  if(type.includes('wav')) return 'wav';
  if(type.includes('ogg')) return 'ogg';
  if(type.includes('pdf')) return 'pdf';
  if(type.includes('json')) return 'json';
  if(type.includes('plain')) return 'txt';
  return 'bin';
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.source !== "CPE_POPUP" && msg?.source !== "CPE_CONTENT") return;

  if (msg.type === "SAVE_SELECTOR") {
    const { origin, selector } = msg;
    chrome.storage.sync.set({ ["cpe::" + origin]: selector }, () => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === "LOAD_SELECTOR") {
    const { origin } = msg;
    chrome.storage.sync.get(["cpe::" + origin], (res) => { sendResponse({ ok: true, selector: res["cpe::" + origin] || null }); });
    return true;
  }

  if (msg.type === "DOWNLOAD_ASSETS") {
    (async () => {
      const { assets, filePrefix } = msg;
      const mapping = {}; let counter = 1;
      const tabs = await chrome.tabs.query({active:true, currentWindow:true});
      const tabId = tabs?.[0]?.id;
      for (const a of assets) {
        const rawUrl = a.url;
        try {
          let filename = '', dataUrl = '';
          if (rawUrl.startsWith('blob:') && tabId) {
            const res = await chrome.tabs.sendMessage(tabId, { source:'CPE_BG', type:'FETCH_BLOB_TO_DATA_URL', url: rawUrl });
            if (res?.ok && res.dataUrl) {
              const ext = res.ext || 'bin';
              filename = `${filePrefix}-${String(counter).padStart(3,'0')}.${ext}`; counter++; dataUrl = res.dataUrl;
            }
          }
          if (!dataUrl) {
            const resp = await fetch(rawUrl, { credentials: 'include' });
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const buf = await resp.arrayBuffer();
            const ct = resp.headers.get('content-type') || '';
            const ext = guessExtFromType(ct) || (a.type?.includes('image') ? 'png' : a.type?.includes('video') ? 'mp4' : 'bin');
            filename = filename || `${filePrefix}-${String(counter).padStart(3,'0')}.${ext}`; counter++;
            const base64 = ab2b64(buf);
            dataUrl = `data:${ct || 'application/octet-stream'};base64,${base64}`;
          }
          await new Promise((resolve) => chrome.downloads.download({ url: dataUrl, filename, conflictAction: 'uniquify' }, () => resolve()));
          mapping[rawUrl] = filename;
        } catch (e) { console.warn('[CPE] Download failed (fetch->data)', rawUrl, e); }
      }
      sendResponse({ ok: true, mapping });
    })();
    return true;
  }
});
