function ab2b64(buf){ var b=''; var a=new Uint8Array(buf); for(var i=0;i<a.length;i++) b+=String.fromCharCode(a[i]); return btoa(b); }
function guessExtFromType(type){
  if(!type) return 'bin';
  if(type.indexOf('png')>=0) return 'png';
  if(type.indexOf('jpeg')>=0||type.indexOf('jpg')>=0) return 'jpg';
  if(type.indexOf('gif')>=0) return 'gif';
  if(type.indexOf('webp')>=0) return 'webp';
  if(type.indexOf('svg')>=0) return 'svg';
  if(type.indexOf('mp4')>=0) return 'mp4';
  if(type.indexOf('webm')>=0) return 'webm';
  if(type.indexOf('quicktime')>=0) return 'mov';
  if(type.indexOf('mp3')>=0) return 'mp3';
  if(type.indexOf('wav')>=0) return 'wav';
  if(type.indexOf('ogg')>=0) return 'ogg';
  if(type.indexOf('pdf')>=0) return 'pdf';
  if(type.indexOf('json')>=0) return 'json';
  if(type.indexOf('plain')>=0) return 'txt';
  return 'bin';
}
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse){
  if (!msg || (msg.source !== "CPE_POPUP" && msg.source !== "CPE_CONTENT")) return;

  if (msg.type === "SAVE_SELECTOR") {
    var origin = msg.origin, selector = msg.selector;
    chrome.storage.sync.set({ ["cpe::" + origin]: selector }, function(){ sendResponse({ ok: true }); });
    return true;
  }
  if (msg.type === "LOAD_SELECTOR") {
    var origin2 = msg.origin;
    chrome.storage.sync.get(["cpe::" + origin2], function(res){ sendResponse({ ok: true, selector: res["cpe::" + origin2] || null }); });
    return true;
  }

  if (msg.type === "DOWNLOAD_ASSETS") {
    (async function(){
      var assets = msg.assets, filePrefix = msg.filePrefix;
      var mapping = {}; var counter = 1;
      var tabs = await chrome.tabs.query({active:true, currentWindow:true});
      var tabId = tabs && tabs[0] && tabs[0].id;
      for (var i=0;i<assets.length;i++) {
        var a = assets[i]; var rawUrl = a.url;
        try {
          var filename = '', dataUrl = '';
          if (rawUrl.indexOf('blob:') === 0 && tabId) {
            var res = await chrome.tabs.sendMessage(tabId, { source:'CPE_BG', type:'FETCH_BLOB_TO_DATA_URL', url: rawUrl });
            if (res && res.ok && res.dataUrl) {
              var ext = res.ext || 'bin';
              filename = filePrefix + '-' + String(counter).padStart(3,'0') + '.' + ext; counter++; dataUrl = res.dataUrl;
            }
          }
          if (!dataUrl) {
            var resp = await fetch(rawUrl, { credentials: 'include' });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            var buf = await resp.arrayBuffer();
            var ct = resp.headers.get('content-type') || '';
            var ext2 = guessExtFromType(ct) || (a.type && a.type.indexOf('image')>=0 ? 'png' : (a.type && a.type.indexOf('video')>=0 ? 'mp4' : 'bin'));
            filename = filename || (filePrefix + '-' + String(counter).padStart(3,'0') + '.' + ext2); counter++;
            var base64 = ab2b64(buf);
            dataUrl = 'data:' + (ct || 'application/octet-stream') + ';base64,' + base64;
          }
          await new Promise(function(resolve){ chrome.downloads.download({ url: dataUrl, filename: filename, conflictAction: 'uniquify' }, function(){ resolve(); }); });
          mapping[rawUrl] = filename;
        } catch (e) { console.warn('[CPE] Download failed (fetch->data)', rawUrl, e); }
      }
      sendResponse({ ok: true, mapping: mapping });
    })();
    return true;
  }
});