
import { cssPath } from "./util.js";
let overlay, outline, label, picking = false, currentEl = null;
function ensureOverlay() {
  if (overlay) return;
  overlay = document.createElement("div");
  overlay.id = "cpe-overlay";
  overlay.innerHTML = `<div class="cpe-outline"></div><div class="cpe-label">点击以选择聊天容器，按 ESC 取消</div>`;
  document.documentElement.appendChild(overlay);
  outline = overlay.querySelector(".cpe-outline");
  label = overlay.querySelector(".cpe-label");
}
function updateOutline(el) {
  const r = el.getBoundingClientRect();
  outline.style.left = `${Math.max(0, r.left + window.scrollX)}px`;
  outline.style.top = `${Math.max(0, r.top + window.scrollY)}px`;
  outline.style.width = `${r.width}px`;
  outline.style.height = `${r.height}px`;
  label.textContent = `选择: ${el.tagName.toLowerCase()}${el.id ? "#"+el.id : ""}`;
}
function onMove(e) {
  if (!picking) return;
  const el = document.elementFromPoint(e.clientX, e.clientY);
  if (el && el !== document.documentElement && el !== document.body) { currentEl = el; updateOutline(el); }
}
function onClick(e) {
  if (!picking) return;
  e.preventDefault(); e.stopPropagation();
  picking = false;
  document.removeEventListener("mousemove", onMove, true);
  document.removeEventListener("click", onClick, true);
  document.removeEventListener("keydown", onKey, true);
  overlay?.remove(); overlay = null; outline = null; label = null;
  const selector = cssPath(currentEl);
  window.postMessage({ source: "CPE_SELECTOR", type: "CONTAINER_PICKED", selector }, "*");
}
function onKey(e) {
  if (e.key === "Escape") {
    picking = false;
    document.removeEventListener("mousemove", onMove, true);
    document.removeEventListener("click", onClick, true);
    document.removeEventListener("keydown", onKey, true);
    overlay?.remove(); overlay = null; outline = null; label = null;
    window.postMessage({ source: "CPE_SELECTOR", type: "CANCEL" }, "*");
  }
}
export function startPicking() {
  ensureOverlay(); picking = true;
  document.addEventListener("mousemove", onMove, true);
  document.addEventListener("click", onClick, true);
  document.addEventListener("keydown", onKey, true);
}
