
import { startPicking } from "./selector.js";
import { extractFromContainer } from "./extractor.js";
import { nowISO } from "./util.js";

const state = { containerSelector: null, lastExtract: null };

function originKey() { try { return new URL(location.href).origin; } catch { return "*"; } }

async function loadSavedSelector() {
  const key = "cpe::" + originKey();
  return new Promise(resolve => {
    try { chrome.storage.sync.get([key], (res) => resolve(res[key] || null)); }
    catch { resolve(null); }
  });
}

function autoDetectContainer() {
  const found = document.querySelector([
    "ul.msg-s-message-list-content",
    "div.msg-s-message-list-content",
    "section.msg-s-message-list",
    "div.msg-conversation__container",
    "main[role='main'] .msg-convo-wrapper",
    "div .msg-s-message-list__events-list"
  ].join(","));
  if (found) return found;
  return document.querySelector("[role='list'], .chat-list, .messages, .conversation, .msg-list");
}

loadSavedSelector().then(sel => { if (sel) state.containerSelector = sel; });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // background asks us to fetch blob: and return data url
  if (msg?.source === 'CPE_BG' && msg.type === 'FETCH_BLOB_TO_DATA_URL') {
    (async () => {
      try {
        const resp = await fetch(msg.url);
        const ct = resp.headers.get('content-type') || 'application/octet-stream';
        const buf = await resp.arrayBuffer();
        const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
        let ext = 'bin';
        if (ct.includes('png')) ext = 'png';
        else if (ct.includes('jpeg') || ct.includes('jpg')) ext = 'jpg';
        else if (ct.includes('gif')) ext = 'gif';
        else if (ct.includes('webp')) ext = 'webp';
        else if (ct.includes('mp4')) ext = 'mp4';
        else if (ct.includes('webm')) ext = 'webm';
        else if (ct.includes('pdf')) ext = 'pdf';
        sendResponse({ ok: true, dataUrl: `data:${ct};base64,${b64}`, ext });
      } catch (err) { sendResponse({ ok: false, error: String(err) }); }
    })(); return true;
  }

  if (msg?.source !== "CPE_POPUP") return;

  if (msg.type === "START_PICK") { startPicking(); sendResponse({ ok: true }); return true; }

  if (msg.type === "EXTRACT") {
    let container = state.containerSelector ? document.querySelector(state.containerSelector) : null;
    if (!container) {
      container = autoDetectContainer();
      if (container && container.id) state.containerSelector = `#${container.id}`;
    }
    if (!container) return sendResponse({ ok: false, error: "未选择或找不到容器（已尝试自动识别失败）" });

    // ensure virtual lists load more (best-effort small scroll)
    try { container.scrollTop = container.scrollHeight; await new Promise(r => setTimeout(r, 50)); } catch {}
    const data = extractFromContainer(container);
    const payload = { pageTitle: document.title, pageUrl: location.href, scrapedAt: nowISO(), containerSelector: state.containerSelector, ...data };
    state.lastExtract = payload;
    sendResponse({ ok: true, payload }); return true;
  }

  if (msg.type === "SET_SELECTOR") {
    state.containerSelector = msg.selector;
    try { chrome.storage.sync.set({ ["cpe::" + originKey()]: state.containerSelector }); } catch {}
    sendResponse({ ok: true }); return true;
  }
});

window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  const data = e.data || {}; if (data.source !== "CPE_SELECTOR") return;
  if (data.type === "CONTAINER_PICKED") {
    state.containerSelector = data.selector;
    try { chrome.storage.sync.set({ ["cpe::" + originKey()]: state.containerSelector }); } catch {}
    chrome.runtime.sendMessage({ source: "CPE_CONTENT", type: "CONTAINER_PICKED", selector: data.selector });
  }
  if (data.type === "CANCEL") chrome.runtime.sendMessage({ source: "CPE_CONTENT", type: "PICK_CANCELLED" });
});
