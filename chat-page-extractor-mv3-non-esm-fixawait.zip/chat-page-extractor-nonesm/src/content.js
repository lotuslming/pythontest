
(() => {
  // ===== util.js (inlined) =====
  function nowISO(){ return new Date().toISOString(); }
  function cssPath(el){
    if (!el || el.nodeType !== 1) return "";
    const path = [];
    while (el && el.nodeType === 1 && el !== document.documentElement) {
      let selector = el.nodeName.toLowerCase();
      if (el.id) { selector += `#${CSS.escape(el.id)}`; path.unshift(selector); break; }
      const cls = [...el.classList].filter(c => c.length <= 32).slice(0, 3);
      if (cls.length) selector += "." + cls.map(c => CSS.escape(c)).join(".");
      const parent = el.parentNode;
      if (parent) {
        const tag = el.tagName;
        const siblings = [...parent.children].filter(n => n.tagName === tag);
        if (siblings.length > 1) { const idx = siblings.indexOf(el) + 1; selector += `:nth-of-type(${idx})`; }
      }
      path.unshift(selector); el = el.parentElement;
    }
    return path.join(" > ");
  }
  function sanitizeText(t){ return (t||"").replace(/\s+/g," ").trim(); }
  function toAbsoluteUrl(u){ try { return new URL(u, location.href).href; } catch { return u; } }
  function originKey(){ try{ return new URL(location.href).origin; }catch{ return "*"; } }

  // ===== selector.js (inlined) =====
  let CPE_overlay, CPE_outline, CPE_label, CPE_picking=false, CPE_currentEl=null;
  function CPE_ensureOverlay(){
    if (CPE_overlay) return;
    const div = document.createElement("div");
    div.id = "cpe-overlay";
    div.innerHTML = `<div class="cpe-outline"></div><div class="cpe-label">点击以选择聊天容器，按 ESC 取消</div>`;
    document.documentElement.appendChild(div);
    CPE_overlay = div;
    CPE_outline = div.querySelector(".cpe-outline");
    CPE_label = div.querySelector(".cpe-label");
  }
  function CPE_updateOutline(el){
    const r = el.getBoundingClientRect();
    CPE_outline.style.left = `${Math.max(0, r.left + window.scrollX)}px`;
    CPE_outline.style.top = `${Math.max(0, r.top + window.scrollY)}px`;
    CPE_outline.style.width = `${r.width}px`;
    CPE_outline.style.height = `${r.height}px`;
    CPE_label.textContent = `选择: ${el.tagName.toLowerCase()}${el.id ? "#"+el.id : ""}`;
  }
  function CPE_onMove(e){
    if (!CPE_picking) return;
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el && el !== document.documentElement && el !== document.body) { CPE_currentEl = el; CPE_updateOutline(el); }
  }
  function CPE_onClick(e){
    if (!CPE_picking) return;
    e.preventDefault(); e.stopPropagation();
    CPE_picking = false;
    document.removeEventListener("mousemove", CPE_onMove, true);
    document.removeEventListener("click", CPE_onClick, true);
    document.removeEventListener("keydown", CPE_onKey, true);
    CPE_overlay?.remove(); CPE_overlay = null; CPE_outline = null; CPE_label = null;
    const selector = cssPath(CPE_currentEl);
    window.postMessage({ source:"CPE_SELECTOR", type:"CONTAINER_PICKED", selector }, "*");
  }
  function CPE_onKey(e){
    if (e.key === "Escape") {
      CPE_picking = false;
      document.removeEventListener("mousemove", CPE_onMove, true);
      document.removeEventListener("click", CPE_onClick, true);
      document.removeEventListener("keydown", CPE_onKey, true);
      CPE_overlay?.remove(); CPE_overlay = null; CPE_outline = null; CPE_label = null;
      window.postMessage({ source:"CPE_SELECTOR", type:"CANCEL" }, "*");
    }
  }
  function startPicking(){
    CPE_ensureOverlay(); CPE_picking = true;
    document.addEventListener("mousemove", CPE_onMove, true);
    document.addEventListener("click", CPE_onClick, true);
    document.addEventListener("keydown", CPE_onKey, true);
  }

  // ===== extractor.js (inlined) =====
  const LINKEDIN_NODE_SEL = "li.msg-s-event-listitem, div.msg-s-message-group__message, div.msg-s-event-listitem__message-bubble";
  const GENERIC_NODE_SEL  = "[role='listitem'], [data-message], [data-testid*='message'], .message, .msg, .chat-message, .bubble, .im_message, .Message, .c-message_kit__message";
  function diagnostics(container){
    const out = {};
    try {
      out.containerExists = !!container;
      if (!container) return out;
      out.hostname = location.hostname;
      out.linkedin = /(^|\.)linkedin\.com$/.test(location.hostname);
      out.counts = {
        linkedinNodes: container.querySelectorAll(LINKEDIN_NODE_SEL).length,
        genericNodes: container.querySelectorAll(GENERIC_NODE_SEL).length
      };
      const sample = [...container.querySelectorAll(LINKEDIN_NODE_SEL)].slice(0,3).map(n => (n.textContent||"").trim().slice(0,80));
      if (sample.length) out.sample = sample;
    } catch(e){ out.diagError = String(e); }
    return out;
  }
  function guessMessageNodes(container){
    try {
      if (/(^|\.)linkedin\.com$/.test(location.hostname)) {
        const li = container.querySelectorAll(LINKEDIN_NODE_SEL);
        if (li.length) return [...li];
      }
    } catch(e){ console.debug("[CPE] guessMessageNodes linkedin branch error:", e); }
    const candidates = container.querySelectorAll(GENERIC_NODE_SEL);
    if (candidates.length) return [...candidates];
    return [...container.children].filter(n => (n.textContent||"").trim().length > 0);
  }
  function findTimestamp(el){
    const liTime = el.querySelector("time[datetime], time, span.msg-s-message-group__timestamp");
    if (liTime){ const dt = liTime.getAttribute("datetime") || liTime.getAttribute("title") || liTime.textContent; if (dt) return sanitizeText(dt); }
    const liAttr = el.getAttribute("data-time"); if (liAttr) return liAttr;
    const t1 = el.querySelector("time[datetime]"); if (t1) return t1.getAttribute("datetime");
    const t2 = el.querySelector("[data-timestamp], [data-time], [data-utime]"); if (t2) return t2.getAttribute("data-timestamp") || t2.getAttribute("data-time") || t2.getAttribute("data-utime");
    const labeled = el.getAttribute("aria-label") || ""; if (/\d{1,4}[:\/.\-]\d{1,2}/.test(labeled)) return labeled;
    const text = el.textContent; const timeLike = text && text.match(/\b(\d{1,2}:\d{2}(?:\s?[AP]M)?)\b/); if (timeLike) return timeLike[0];
    return null;
  }
  function findSender(el){
    const liSender = el.querySelector("a.msg-s-message-group__profile-link, span.msg-s-message-group__name, span[dir][data-anonymize]");
    if (liSender) return sanitizeText(liSender.textContent || "");
    const s = el.querySelector(".sender, .author, .from, .nickname, .name, [data-author], [data-sender], [aria-label*='来自']");
    if (!s) return null;
    return sanitizeText(s.textContent || s.getAttribute("aria-label") || "");
  }
  function extractAttachments(el){
    const list = [];
    const medias = el.querySelectorAll("img, video, audio, a[download], a[href]");
    for (const m of medias) {
      if (m.tagName === "IMG") list.push({ type:"image", url: toAbsoluteUrl(m.currentSrc || m.src) });
      else if (m.tagName === "VIDEO") {
        const src = m.currentSrc || (m.querySelector("source")?.src) || m.src;
        if (src) list.push({ type:"video", url: toAbsoluteUrl(src) });
      } else if (m.tagName === "A") {
        const href = m.getAttribute("href"); if (!href) continue;
        const abs = toAbsoluteUrl(href);
        const isMedia = /\.(png|jpe?g|gif|webp|svg|mp4|mov|webm|mp3|wav|ogg)(\?|$)/i.test(abs);
        list.push({ type: isMedia ? "file/media" : "file", url: abs, name: (m.textContent||'').trim() || undefined });
      } else if (m.tagName === "AUDIO") {
        const src = m.currentSrc || (m.querySelector("source")?.src) || m.src;
        if (src) list.push({ type:"audio", url: toAbsoluteUrl(src) });
      }
    }
    const seen = new Set(); return list.filter(x => { const k = `${x.type}|${x.url}`; if (seen.has(k)) return false; seen.add(k); return true; });
  }
  function extractFromContainer(container){
    try {
      const nodes = guessMessageNodes(container);
      if (!nodes || !nodes.length) {
        console.error("[CPE][CPE_ERR_NO_MESSAGES] 容器内未找到消息节点。", diagnostics(container));
        return { count:0, messages:[], __code:"CPE_ERR_NO_MESSAGES" };
      }
      const messages = nodes.map((node, idx) => {
        const text = sanitizeText(node.textContent || "");
        const html = node.innerHTML;
        const timestamp = findTimestamp(node);
        const sender = findSender(node);
        const attachments = extractAttachments(node);
        return { index: idx, sender, text, html, timestamp, attachments };
      }).filter(m => (m.text && m.text.length) || (m.attachments && m.attachments.length));
      return { count: messages.length, messages };
    } catch (e) {
      console.error("[CPE][CPE_ERR_EXTRACT_EXCEPTION] 提取过程中异常：", e);
      return { count:0, messages:[], __code:"CPE_ERR_EXTRACT_EXCEPTION", __err:String(e) };
    }
  }

  // ===== content pipeline =====
  const state = { containerSelector: null, lastExtract: null };

  function autoDetectContainer(){
    const found = document.querySelector([
      "ul.msg-s-message-list-content",
      "div.msg-s-message-list-content",
      "section.msg-s-message-list",
      "div.msg-conversation__container",
      "main[role='main'] .msg-convo-wrapper",
      "div .msg-s-message-list__events-list"
    ].join(","));
    if (found) return found;
    return document.querySelector("[role='list'], .chat-list, .messages, .conversation, .msg-list");
  }
  // preload saved selector
  (function(){
    const key = "cpe::" + originKey();
    try {
      chrome.storage.sync.get([key], (res) => {
        if (res && res[key]) { state.containerSelector = res[key]; console.debug("[CPE] Loaded saved selector:", res[key]); }
      });
    } catch {}
  })();

  // Messages from popup or background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.source === 'CPE_BG' && msg.type === 'FETCH_BLOB_TO_DATA_URL') {
      (async () => {
        try {
          const resp = await fetch(msg.url);
          const ct = resp.headers.get('content-type') || 'application/octet-stream';
          const buf = await resp.arrayBuffer();
          const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
          let ext = 'bin';
          if (ct.includes('png')) ext = 'png';
          else if (ct.includes('jpeg') || ct.includes('jpg')) ext = 'jpg';
          else if (ct.includes('gif')) ext = 'gif';
          else if (ct.includes('webp')) ext = 'webp';
          else if (ct.includes('mp4')) ext = 'mp4';
          else if (ct.includes('webm')) ext = 'webm';
          else if (ct.includes('pdf')) ext = 'pdf';
          sendResponse({ ok:true, dataUrl:`data:${ct};base64,${b64}`, ext });
        } catch (err) { sendResponse({ ok:false, error:String(err) }); }
      })();
      return true;
    }

    if (msg?.source !== "CPE_POPUP") return;

    if (msg.type === "START_PICK") { startPicking(); sendResponse({ ok:true }); return true; }

    
if (msg.type === "EXTRACT") {
  (async () => {
    try {
      let container = state.containerSelector ? document.querySelector(state.containerSelector) : null;
      if (!container) {
        container = autoDetectContainer();
        if (container && container.id) state.containerSelector = `#${container.id}`;
        console.debug("[CPE] Auto-detected container:", container);
      }
      if (!container) {
        const diag = diagnostics(document.body);
        console.error("[CPE][CPE_ERR_NO_CONTAINER] 未选择或找不到容器。诊断：", diag, "选择器：", state.containerSelector);
        sendResponse({ ok:false, error:"未选择或找不到容器", code:"CPE_ERR_NO_CONTAINER", diag });
        return;
      }
      try { container.scrollTop = container.scrollHeight; await new Promise(r => setTimeout(r, 40)); } catch {}
      const data = extractFromContainer(container);
      if ((data.__code === "CPE_ERR_NO_MESSAGES") || data.count === 0) {
        const diag = diagnostics(container);
        console.error("[CPE][CPE_ERR_NO_MESSAGES] 容器内未找到消息节点。诊断：", diag, "容器选择器：", state.containerSelector);
        sendResponse({ ok:false, error:"容器内未找到消息节点", code:"CPE_ERR_NO_MESSAGES", diag });
        return;
      }
      if (data.__code === "CPE_ERR_EXTRACT_EXCEPTION") {
        console.error("[CPE][CPE_ERR_EXTRACT_EXCEPTION] 异常：", data.__err);
        sendResponse({ ok:false, error:data.__err || "提取过程中异常", code:"CPE_ERR_EXTRACT_EXCEPTION" });
        return;
      }
      const payload = { pageTitle: document.title, pageUrl: location.href, scrapedAt: nowISO(), containerSelector: state.containerSelector, ...data };
      state.lastExtract = payload;
      console.debug("[CPE] Extracted messages:", payload.count);
      sendResponse({ ok:true, payload });
    } catch (e) {
      console.error("[CPE][CPE_ERR_CONTENT_EXCEPTION] 内容脚本异常：", e);
      sendResponse({ ok:false, error:String(e), code:"CPE_ERR_CONTENT_EXCEPTION" });
    }
  })();
  return true;
}
`;
          console.debug("[CPE] Auto-detected container:", container);
        }
        if (!container) {
          const diag = diagnostics(document.body);
          console.error("[CPE][CPE_ERR_NO_CONTAINER] 未选择或找不到容器。诊断：", diag, "选择器：", state.containerSelector);
          sendResponse({ ok:false, error:"未选择或找不到容器", code:"CPE_ERR_NO_CONTAINER", diag });
          return true;
        }
        try { container.scrollTop = container.scrollHeight; await new Promise(r => setTimeout(r, 40)); } catch {}
        const data = extractFromContainer(container);
        if ((data.__code === "CPE_ERR_NO_MESSAGES") || data.count === 0) {
          const diag = diagnostics(container);
          console.error("[CPE][CPE_ERR_NO_MESSAGES] 容器内未找到消息节点。诊断：", diag, "容器选择器：", state.containerSelector);
          sendResponse({ ok:false, error:"容器内未找到消息节点", code:"CPE_ERR_NO_MESSAGES", diag });
          return true;
        }
        if (data.__code === "CPE_ERR_EXTRACT_EXCEPTION") {
          console.error("[CPE][CPE_ERR_EXTRACT_EXCEPTION] 异常：", data.__err);
          sendResponse({ ok:false, error:data.__err || "提取过程中异常", code:"CPE_ERR_EXTRACT_EXCEPTION" });
          return true;
        }
        const payload = { pageTitle: document.title, pageUrl: location.href, scrapedAt: nowISO(), containerSelector: state.containerSelector, ...data };
        state.lastExtract = payload;
        console.debug("[CPE] Extracted messages:", payload.count);
        sendResponse({ ok:true, payload }); return true;
      } catch (e) {
        console.error("[CPE][CPE_ERR_CONTENT_EXCEPTION] 内容脚本异常：", e);
        sendResponse({ ok:false, error:String(e), code:"CPE_ERR_CONTENT_EXCEPTION" });
        return true;
      }
    }

    if (msg.type === "SET_SELECTOR") {
      state.containerSelector = msg.selector;
      try { chrome.storage.sync.set({ ["cpe::" + originKey()]: state.containerSelector }); } catch {}
      console.debug("[CPE] Selector set to:", state.containerSelector);
      sendResponse({ ok:true }); return true;
    }
  });

  // Bridge events from selector overlay back to popup
  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    const data = e.data || {}; if (data.source !== "CPE_SELECTOR") return;
    if (data.type === "CONTAINER_PICKED") {
      state.containerSelector = data.selector;
      try { chrome.storage.sync.set({ ["cpe::" + originKey()]: state.containerSelector }); } catch {}
      console.debug("[CPE] Container picked:", data.selector);
      chrome.runtime.sendMessage({ source:"CPE_CONTENT", type:"CONTAINER_PICKED", selector:data.selector });
    }
    if (data.type === "CANCEL") chrome.runtime.sendMessage({ source:"CPE_CONTENT", type:"PICK_CANCELLED" });
  });
})(); 
